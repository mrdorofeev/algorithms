#include <iostream>

long long partition(int, int);

int main() {
    int n, k;
    std::cin >> n >> k;
    std::cout << partition(n, k);
}

long long partition(int n, int k) {
    long long** a = new long long* [2];
    for (int i = 0; i < 2; ++i) {
        a[i] = new long long[n];
    }
    for (int i = 0; i < n; ++i) {
        a[0][i] = 1;
    }
    int k1 = 1;
    int swap = 0;
    for (int i = 0; i < k - 1; ++i) {
        if (swap == 1) swap = 0;
        else swap = 1;
        for (int j = 0; j < n; ++j) {
            if (j == k1) a[swap][j] = 1;
            else if (k1 > j) a[swap][j] = 0;
            else a[swap][j] = a[swap][j - k1 - 1] + a[abs(swap - 1)][j - 1];
        }
        k1++;
    }
    long long res = a[swap][n - 1];
    for (int i = 0; i < 2; i++) delete[] a[i];
    delete[] a;
    return res;
}